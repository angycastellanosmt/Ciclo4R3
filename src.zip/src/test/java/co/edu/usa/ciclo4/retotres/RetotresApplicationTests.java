package co.edu.usa.ciclo4.retotres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetotresApplicationTests {

	@Test
	void contextLoads() {
	}

}
